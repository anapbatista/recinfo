# Documentos de contexto da avaliação do RAG

Documentos enviados à LLM, na ordem das respostas da planilha de avaliação (R01 a R20) e, dentro de cada resposta, na ordem em que aparecem no contexto. Cada consulta tem duas respostas que usam os **mesmos cinco documentos**; eles aparecem por extenso na primeira resposta da consulta, e a segunda aponta para ela.

O texto de cada documento é o do `corpus.jsonl` (título e resumo). Os rótulos de seção dos resumos (BACKGROUND, METHODS, RESULTS...) foram separados em parágrafos para facilitar a leitura; o conteúdo não foi alterado.

## Índice

- [R01](#r01) · PLAIN-3342 · Is Coconut Milk Good For You?
- [R02](#r02) · PLAIN-153 · How Should I Take Probiotics?
- [R03](#r03) · PLAIN-2430 · Preventing Brain Loss with B Vitamins?
- [R04](#r04) · PLAIN-153 · How Should I Take Probiotics? (mesmos documentos de [R02](#r02))
- [R05](#r05) · PLAIN-2750 · Preventing the Common Cold with Probiotics?
- [R06](#r06) · PLAIN-2470 · Is Milk Good for Our Bones?
- [R07](#r07) · PLAIN-2430 · Preventing Brain Loss with B Vitamins? (mesmos documentos de [R03](#r03))
- [R08](#r08) · PLAIN-3342 · Is Coconut Milk Good For You? (mesmos documentos de [R01](#r01))
- [R09](#r09) · PLAIN-2850 · More Antibiotics In White Meat or Dark Meat?
- [R10](#r10) · PLAIN-2470 · Is Milk Good for Our Bones? (mesmos documentos de [R06](#r06))
- [R11](#r11) · PLAIN-238 · How Chemically Contaminated Are We?
- [R12](#r12) · PLAIN-270 · Is Caffeinated Tea Really Dehydrating?
- [R13](#r13) · PLAIN-68 · What is Actually in Chicken Nuggets?
- [R14](#r14) · PLAIN-270 · Is Caffeinated Tea Really Dehydrating? (mesmos documentos de [R12](#r12))
- [R15](#r15) · PLAIN-2450 · Are Organic Foods Safer?
- [R16](#r16) · PLAIN-238 · How Chemically Contaminated Are We? (mesmos documentos de [R11](#r11))
- [R17](#r17) · PLAIN-2850 · More Antibiotics In White Meat or Dark Meat? (mesmos documentos de [R09](#r09))
- [R18](#r18) · PLAIN-2750 · Preventing the Common Cold with Probiotics? (mesmos documentos de [R05](#r05))
- [R19](#r19) · PLAIN-68 · What is Actually in Chicken Nuggets? (mesmos documentos de [R13](#r13))
- [R20](#r20) · PLAIN-2450 · Are Organic Foods Safer? (mesmos documentos de [R15](#r15))

---

<a id="r01"></a>

## R01 · PLAIN-3342 · Is Coconut Milk Good For You?

Contexto: MED-5014, MED-5015, MED-4000, MED-4002, MED-5012 · cerca de 1187 palavras · também usado em: [R08](#r08)

### 1. MED-5014 · Dietary intake and the risk of coronary heart disease among the coconut-consuming Minangkabau in West Sumatra, Indonesia.

Several nutrition and non-nutritional pathways are recognised in the development and occurrence of cardiovascular disease. In many populations, high intakes of saturated fat are associated with elevated serum cholesterol concentrations and increased coronary heart disease (CHD) mortality. However, several studies report that hyperlipidaemia and heart diseases are not common among populations who consume coconut, a source of saturated fat. A case-control study was conducted among the Minangkabau known to be high coconut consumers to examine the difference in food patterns and risk of coronary heart disease (CHD) between the coronary cases and their gender- and age-matched apparently healthy counterparts serving as controls. Eligible subjects with CHD were identified through the co-operation of five participating hospitals located in Padang and Bukittinggi in West Sumatra, Indonesia. A total of 93 eligible cases (62 men and 31 women) in the Case group and 189 subjects (113 men and 76 women) in the Control group were recruited. Information on the intakes of individual foods and dishes over the preceding 12 months was obtained using a semi-quantitative food frequency questionnaire. The Case groups had significantly higher intakes of meats, eggs, sugar, tea, coffee and fruits, but lower intakes of soy products, rice and cereals compared to the controls. Coconut consumption as flesh or milk was not different between cases and controls. The cases had significantly higher intakes of protein and cholesterol, but lower intake of carbohydrate. Similar intakes of saturated and unsaturated fatty acids between the cases and controls indicated that the consumption of total fat or saturated fat, including that from coconut, was not a predictor for CHD in this food culture. However, the intakes of animal foods, total protein, dietary cholesterol and less plant derived carbohydrates were predictors of CHD.

### 2. MED-5015 · The intravenous use of coconut water.

Medical resources routinely used for intravenous hydration and resuscitation of critically ill patients may be limited in remote regions of the world. When faced with these shortages, physicians have had to improvise with the available resources, or simply do without. We report the successful use of coconut water as a short-term intravenous hydration fluid for a Solomon Island patient, a laboratory analysis of the local coconuts, and a review of previously documented intravenous coconut use.

### 3. MED-4000 · Coconut oil predicts a beneficial lipid profile in pre-menopausal women in the Philippines

Coconut oil is a common edible oil in many countries, and there is mixed evidence for its effects on lipid profiles and cardiovascular disease risk. Here we examine the association between coconut oil consumption and lipid profiles in a cohort of 1,839 Filipino women (age 35–69 years) participating in the Cebu Longitudinal Health and Nutrition Survey, a community based study in Metropolitan Cebu City. Coconut oil intake was measured as individual coconut oil intake calculated using two 24-hour dietary recalls (9.54 ± 8.92 grams). Cholesterol profiles were measured in plasma samples collected after an overnight fast. Mean lipid values in this sample were total cholesterol (TC) (186.52 ± 38.86 mg/dL), high density lipoprotein cholesterol (HDL-c) (40.85 ± 10.30 mg/dL), low density lipoprotein cholesterol (LDL-c) (119.42 ± 33.21 mg/dL), triglycerides (130.75 ± 85.29 mg/dL) and the TC/HDL ratio (4.80 ± 1.41). Linear regression models were used to estimate the association between coconut oil intake and each plasma lipid outcome after adjusting for total energy intake, age, body mass index (BMI), number of pregnancies, education, menopausal status, household assets and urban residency. Dietary coconut oil intake was positively associated with HDL-c levels.

### 4. MED-4002 · Effects of dietary coconut oil on the biochemical and anthropometric profiles of women presenting abdominal obesity.

The effects of dietary supplementation with coconut oil on the biochemical and anthropometric profiles of women presenting waist circumferences (WC) >88 cm (abdominal obesity) were investigated. The randomised, double-blind, clinical trial involved 40 women aged 20-40 years. Groups received daily dietary supplements comprising 30 mL of either soy bean oil (group S; n = 20) or coconut oil (group C; n = 20) over a 12-week period, during which all subjects were instructed to follow a balanced hypocaloric diet and to walk for 50 min per day. Data were collected 1 week before (T1) and 1 week after (T2) dietary intervention. Energy intake and amount of carbohydrate ingested by both groups diminished over the trial, whereas the consumption of protein and fibre increased and lipid ingestion remained unchanged. At T1 there were no differences in biochemical or anthropometric characteristics between the groups, whereas at T2 group C presented a higher level of HDL (48.7 +/- 2.4 vs. 45.00 +/- 5.6; P = 0.01) and a lower LDL:HDL ratio (2.41 +/- 0.8 vs. 3.1 +/- 0.8; P = 0.04). Reductions in BMI were observed in both groups at T2 (P < 0.05), but only group C exhibited a reduction in WC (P = 0.005). Group S presented an increase (P < 0.05) in total cholesterol, LDL and LDL:HDL ratio, whilst HDL diminished (P = 0.03). Such alterations were not observed in group C. It appears that dietetic supplementation with coconut oil does not cause dyslipidemia and seems to promote a reduction in abdominal obesity.

### 5. MED-5012 · The cholesterol-lowering effect of coconut flakes in humans with moderately raised serum cholesterol.

This study investigated the effect of coconut flakes on serum cholesterol levels of humans with moderately raised serum cholesterol in 21 subjects. The serum total cholesterol of subjects differed and ranged from 259 to 283 mg/dL. The study was conducted in a double-blind randomized crossover design on a 14-week period, consisting of four 2-week experimental periods, with each experimental period separated by a 2-week washout period. The test foods were as follows: corn flakes as the control food, oat bran flakes as the reference food, and corn flakes with 15% and 25% dietary fiber from coconut flakes (made from coconut flour production). Results showed a significant percent reduction in serum total and low-density lipoprotein (LDL) cholesterol (in mg/dL) for all test foods, except for corn flakes, as follows: oat bran flakes, 8.4 +/- 1.4 and 8.8 +/- 6.0, respectively; 15% coconut flakes, 6.9 +/- 1.1 and 11.0 +/- 4.0, respectively; and 25% coconut flakes, 10.8 +/- 1.3 and 9.2 +/- 5.4, respectively. Serum triglycerides were significantly reduced for all test foods: corn flakes, 14.5 +/- 6.3%; oat bran flakes, 22.7 +/- 2.9%; 15% coconut flakes, 19.3 +/- 5.7%; and 25% coconut flakes, 21.8 +/- 6.0%. Only 60% of the subjects were considered for serum triglycerides reduction (serum triglycerides >170 mg/dL). In conclusion, both 15% and 25% coconut flakes reduced serum total and LDL cholesterol and serum triglycerides of humans with moderately raised serum cholesterol levels. Coconut flour is a good source of both soluble and insoluble dietary fiber, and both types of fiber may have significant role in the reduction of the above lipid biomarker. To our knowledge, this is the first study conducted to show a relationship between dietary fiber from a coconut by-product and a lipid biomarker. Results from this study serves as a good basis in the development of coconut flakes/flour as a functional food, justifying the increased production of coconut and coconut by-products.

---

<a id="r02"></a>

## R02 · PLAIN-153 · How Should I Take Probiotics?

Contexto: MED-3679, MED-3692, MED-3695, MED-3693, MED-3680 · cerca de 1529 palavras · também usado em: [R04](#r04)

### 1. MED-3679 · The impact of meals on a probiotic during transit through a model of the human upper gastrointestinal tract.

Commercial literature on various probiotic products suggests that they can be taken before meals, during meals or after meals or even without meals. This has led to serious confusion for the industry and the consumer. The objective of our study was to examine the impact of the time of administration with respect to mealtime and the impact of the buffering capacity of the food on the survival of probiotic microbes during gastrointestinal transit. We used an in vitro Digestive System (IViDiS) model of the upper gastrointestinal tract to examine the survival of a commercial multi-strain probiotic, ProtecFlor®. This product, in a capsule form, contains four different microbes: two lactobacilli (Lactobacillus helveticus R0052 and Lactobacillus rhamnosus R0011), Bifidobacterium longum R0175 and Saccharomyces cerevisiae boulardii. Enumeration during and after transit of the stomach and duodenal models showed that survival of all the bacteria in the product was best when given with a meal or 30 minutes before a meal (cooked oatmeal with milk). Probiotics given 30 minutes after the meal did not survive in high numbers. Survival in milk with 1% milk fat and oatmeal-milk gruel were significantly better than apple juice or spring water. S. boulardii was not affected by time of meal or the buffering capacity of the meal. The protein content of the meal was probably not as important for the survival of the bacteria as the fat content. We conclude that ideally, non-enteric coated bacterial probiotic products should be taken with or just prior to a meal containing some fats.

### 2. MED-3692 · Human gut microbiota and its relationship to health and disease.

Probiotics are live microorganisms that confer a health benefit on the host when administered in appropriate amounts. Over 700 randomized, controlled, human studies have been conducted with probiotics thus far, with the results providing strong support for the use of probiotics in the clinical prevention or treatment of gastrointestinal tract disorders and metabolic syndrome. The present review is based on webinar presentations that were developed by the American Gastroenterological Association (AGA) in partnership with the International Scientific Association for Probiotics and Prebiotics (ISAPP) and the North American branch of the International Life Sciences Institute (ILSI North America). The presentations provided gastroenterologists and researchers with fundamental and current scientific information on the influence of gut microbiota on human health and disease, as well as clinical intervention strategies and practical guidelines for the use of probiotics and prebiotics. © 2011 International Life Sciences Institute.

### 3. MED-3695 · Probiotics for the prevention of pediatric antibiotic-associated diarrhea.

**BACKGROUND:** Antibiotics alter the microbial balance within the gastrointestinal tract. Probiotics may prevent antibiotic-associated diarrhea (AAD) via restoration of the gut microflora. Antibiotics are prescribed frequently in children and AAD is common in this population.

**OBJECTIVES:** To assess the efficacy and adverse effects of probiotics (any specified strain or dose) for the prevention of antibiotic-associated diarrhea in children. To assess adverse events associated with the use of probiotics when co-administered with antibiotics in children.

**SEARCH STRATEGY:** MEDLINE, EMBASE, CENTRAL, CINAHL , AMED, and the Web of Science (inception to August 2006) were searched along with specialized registers including the Cochrane IBD/FBD Review Group, CISCOM, Chalmers PedCAM Research Register and trial registries from inception to 2005. Letters were sent to authors of included trials, nutra/pharmaceutical companies, and experts in the field requesting additional information on ongoing or unpublished trials. Conference proceedings, dissertation abstracts, and reference lists from included and relevant articles were hand searched.

**SELECTION CRITERIA:** Randomized, parallel, controlled (placebo, active, or no treatment) trials comparing co-administered probiotics with antibiotics for the prevention of diarrhea secondary to antibiotic use in children (0 to 18 years).

**DATA COLLECTION AND ANALYSIS:** Methodological quality assessment and data extraction were conducted independently by two authors (BCJ, AS). Dichotomous data (incidence of diarrhea, adverse events) were combined using pooled relative risks, and continuous data (mean duration of diarrhea, mean daily stool frequency) as weighted mean differences, along with their corresponding 95% confidence intervals. Adverse events were summarized using risk difference. For overall pooled results on the incidence of diarrhea, a priori sensitivity analyses included per protocol versus intention to treat, random versus fixed effects, and methodological quality criterion. Subgroup analysis were conducted on probiotic strain, dose, definition of antibiotic-associated diarrhea, and antibiotic agent.

**MAIN RESULTS:** Ten studies met the inclusion criteria. Trials included treatment with either Lactobacilli spp., Bifidobacterium spp., Streptococcus spp., or Saccharomyces boulardii alone or in combination. Six studies used a single strain probiotic agent and four combined two probiotic strains. The per protocol analysis for 9/10 trials reporting on the incidence of diarrhea show statistically significant results favouring probiotics over active/non active controls (RR 0.49; 95% CI 0.32 to 0.74). However, intention to treat analysis showed non-significant results overall (RR 0.90; 95% CI 0.50 to 1.63). Five of ten trials monitored for adverse events (n = 647); none reported a serious adverse event.

**AUTHORS' CONCLUSIONS:** Probiotics show promise for the prevention of pediatric AAD. While per protocol analysis yields treatment effect estimates that are both statistically and clinically significant, as does analysis of high quality studies, the estimate from the intention to treat analysis was not statistically significant. Future studies should involve probiotic strains and doses with the most promising evidence (e.g., Lactobacillus GG, Lactobacillus sporogenes, Saccharomyces boulardii at 5 to 40 billion colony forming units/day). Research done to date does not permit determination of the effect of age (e.g., infant versus older children) or antibiotic duration (e.g., 5 days versus 10 days). Future trials would benefit from a validated primary outcome measure for antibiotic-associated diarrhea that is sensitive to change and reflects what treatment effect clinicians, parents, and children consider important. The current data are promising, but it is premature to routinely recommend probiotics for the prevention of pediatric AAD.

### 4. MED-3693 · Microbiological evaluation of commercial probiotic products available in the USA in 2009.

Probiotics are widely used to prevent and treat several diseases. Many commercial products are available worldwide. However, there is no clear international or local legislation about them and previous studies showed that most of the tested products are not in conformity with international guidelines. The aim of this study was to determine if products available in the USA market in 2009 were correctly labeled in terms of quantity of viable bacteria, identification of species and cross contamination by species not on the label. Disturbingly, we found that only 4 of 13 products (31%) were in accordance with label claims. Our results suggest the need for adequate control of probiotic production as well as periodical screenings by competent organizations to monitor the effect of storage on product quality.

### 5. MED-3680 · Probiotics for preventing acute upper respiratory tract infections.

**BACKGROUND:** Probiotics may improve a person's health by regulating their immune function. Some studies show that probiotic strains can prevent respiratory infections. However, no evidence of the benefits of probiotics for acute upper respiratory tract infections (URTIs) and related potential adverse effects has been published.

**OBJECTIVES:** To assess the effectiveness and safety of probiotics for preventing acute URTIs.

**SEARCH STRATEGY:** We searched the Cochrane Central Register of Controlled Trials (CENTRAL) (The Cochrane Library 2011, Issue 2), which includes the Cochrane Acute Respiratory Infections Group's Specialised Register, MEDLINE (Ovid) (1950 to May week 1, 2011), EMBASE (1974 to May 2011), Web of Science which includes Science Citation Index (from 1900 to May 2011) and Conference Proceedings Citation Index (from 1991 to May 2011), the Chinese Biomedical Literature Database, which includes the China Biological Medicine Database (from 1978 to May 2011), the Chinese Medicine Popular Science Literature Database (from 2000 to May 2011) and the Masters Degree Dissertation of Beijing Union Medical College Database (from 1981 to May 2011).

**SELECTION CRITERIA:** Randomised controlled trials (RCTs) comparing probiotics with placebo to prevent acute URTIs.

**DATA COLLECTION AND ANALYSIS:** Two review authors independently assessed eligibility, quality of trials and extracted data.

**MAIN RESULTS:** We included 14 RCTs, although we could only extract available data to meta-analyse in 10 trials which involved 3451 participants. We found that probiotics were better than placebo when measuring the number of participants experiencing episodes of acute URTI: at least one episode: odds ratio (OR) 0.58; 95% confidence interval (CI) 0.36 to 0.92; at least three episodes: OR 0.53; 95% CI 0.36 to 0.80; rate ratio of episodes of acute URTI: rate ratio 0.88; 95% CI 0.81 to 0.96; and reduced antibiotic prescription rates for acute URTIs: OR 0.67; 95% CI 0.45 to 0.98. Probiotics and placebo were similar when measuring the mean duration (MD) of an episode of acute URTI: MD -0.29; 95% CI -3.71 to 3.13 and adverse events: OR 0.92; 95% CI 0.37 to 2.28. Side effects of probiotics were minor and gastrointestinal symptoms were the most common. We found that some subgroups had a high level of heterogeneity when conducting pooled analyses.

**AUTHORS' CONCLUSIONS:** Probiotics were better than placebo in reducing the number of participants experiencing episodes of acute URTIs, the rate ratio of episodes of acute URTI and reducing antibiotic use. This indicates that probiotics may be more beneficial than placebo for preventing acute URTIs. However, the results have some limitations and there were no data for older people.

---

<a id="r03"></a>

## R03 · PLAIN-2430 · Preventing Brain Loss with B Vitamins?

Contexto: MED-994, MED-980, MED-5128, MED-986, MED-4929 · cerca de 1583 palavras · também usado em: [R07](#r07)

### 1. MED-994 · Preventing Alzheimer’s disease-related gray matter atrophy by B-vitamin treatment

Is it possible to prevent atrophy of key brain regions related to cognitive decline and Alzheimer’s disease (AD)? One approach is to modify nongenetic risk factors, for instance by lowering elevated plasma homocysteine using B vitamins. In an initial, randomized controlled study on elderly subjects with increased dementia risk (mild cognitive impairment according to 2004 Petersen criteria), we showed that high-dose B-vitamin treatment (folic acid 0.8 mg, vitamin B6 20 mg, vitamin B12 0.5 mg) slowed shrinkage of the whole brain volume over 2 y. Here, we go further by demonstrating that B-vitamin treatment reduces, by as much as seven fold, the cerebral atrophy in those gray matter (GM) regions specifically vulnerable to the AD process, including the medial temporal lobe. In the placebo group, higher homocysteine levels at baseline are associated with faster GM atrophy, but this deleterious effect is largely prevented by B-vitamin treatment. We additionally show that the beneficial effect of B vitamins is confined to participants with high homocysteine (above the median, 11 µmol/L) and that, in these participants, a causal Bayesian network analysis indicates the following chain of events: B vitamins lower homocysteine, which directly leads to a decrease in GM atrophy, thereby slowing cognitive decline. Our results show that B-vitamin supplementation can slow the atrophy of specific brain regions that are a key component of the AD process and that are associated with cognitive decline. Further B-vitamin supplementation trials focusing on elderly subjets with high homocysteine levels are warranted to see if progression to dementia can be prevented.

### 2. MED-980 · Homocysteine-Lowering by B Vitamins Slows the Rate of Accelerated Brain Atrophy in Mild Cognitive Impairment: A Randomized Controlled Trial

Background An increased rate of brain atrophy is often observed in older subjects, in particular those who suffer from cognitive decline. Homocysteine is a risk factor for brain atrophy, cognitive impairment and dementia. Plasma concentrations of homocysteine can be lowered by dietary administration of B vitamins. Objective To determine whether supplementation with B vitamins that lower levels of plasma total homocysteine can slow the rate of brain atrophy in subjects with mild cognitive impairment in a randomised controlled trial (VITACOG, ISRCTN 94410159). Methods and Findings Single-center, randomized, double-blind controlled trial of high-dose folic acid, vitamins B6 and B12 in 271 individuals (of 646 screened) over 70 y old with mild cognitive impairment. A subset (187) volunteered to have cranial MRI scans at the start and finish of the study. Participants were randomly assigned to two groups of equal size, one treated with folic acid (0.8 mg/d), vitamin B12 (0.5 mg/d) and vitamin B6 (20 mg/d), the other with placebo; treatment was for 24 months. The main outcome measure was the change in the rate of atrophy of the whole brain assessed by serial volumetric MRI scans. Results A total of 168 participants (85 in active treatment group; 83 receiving placebo) completed the MRI section of the trial. The mean rate of brain atrophy per year was 0.76% \[95% CI, 0.63–0.90\] in the active treatment group and 1.08% \[0.94–1.22\] in the placebo group (P = 0.001). The treatment response was related to baseline homocysteine levels: the rate of atrophy in participants with homocysteine >13 µmol/L was 53% lower in the active treatment group (P = 0.001). A greater rate of atrophy was associated with a lower final cognitive test scores. There was no difference in serious adverse events according to treatment category. Conclusions and Significance The accelerated rate of brain atrophy in elderly with mild cognitive impairment can be slowed by treatment with homocysteine-lowering B vitamins. Sixteen percent of those over 70 y old have mild cognitive impairment and half of these develop Alzheimer's disease. Since accelerated brain atrophy is a characteristic of subjects with mild cognitive impairment who convert to Alzheimer's disease, trials are needed to see if the same treatment will delay the development of Alzheimer's disease. Trial Registration Controlled-Trials.com ISRCTN94410159

### 3. MED-5128 · Low vitamin B-12 status and risk of cognitive decline in older adults.

**BACKGROUND:** Elevated total homocysteine (tHcy) concentrations have been associated with cognitive impairment, but it is unclear whether low vitamin B-12 or folate status is responsible for cognitive decline.

**OBJECTIVE:** We examined the associations of cognitive decline with vitamin B-12 and folate status in a longitudinal cohort study performed from 1993 to 2003 in Oxford, United Kingdom.

**DESIGN:** Cognitive function was assessed with the Mini-Mental State Examination on >/=3 occasions during 10 y and related to serum concentrations of vitamin B-12, holotranscobalamin (holoTC), tHcy, methylmalonic acid (MMA), and folate with the use of linear mixed models in 1648 participants who provided blood in 1995.

**RESULTS:** Cognitive function declined abruptly at younger ages in some participants but remained intact in others until very old age. In multivariate regression analyses after adjustment for established risk factors, concentrations of holoTC (a marker of reduced vitamin B-12 status), tHcy, and MMA predicted cognitive decline, but folate did not. A doubling in holoTC concentrations (from 50 to 100 pmol/L) was associated with a 30% slower rate of cognitive decline (-0.137 to -0.083), whereas a doubling in tHcy (from 10 to 20 micromol/L) or MMA (from 0.25 to 0.50 micromol/L) was associated with >50% more rapid cognitive decline (-0.090 to -0.169) and (-0.104 to -0.169), respectively. After adjustment for all vitamin markers simultaneously, the associations of cognitive decline with holoTC and MMA remained significant.

**CONCLUSIONS:** Low vitamin B-12 status was associated with more rapid cognitive decline. Randomized trials are required to determine the relevance of vitamin B-12 supplementation for prevention of dementia.

### 4. MED-986 · Effect of homocysteine lowering treatment on cognitive function: a systematic review and meta-analysis of randomized controlled trials.

Elevated total plasma homocysteine has been linked to the development of cognitive impairment and dementia in later life and this can be reliably lowered by the daily supplementation of vitamin B6, B12, and folic acid. We performed a systematic review and meta-analysis of 19 English language randomized, placebo-controlled trials of homocysteine lowering B-vitamin supplementation of individuals with and without cognitive impairment at the time of study entry. We standardized scores to facilitate comparison between studies and to enable us to complete a meta-analysis of randomized trials. In addition, we stratified our analyses according to the folate status of the country of origin. B-vitamin supplementation did not show an improvement in cognitive function for individuals with (SMD = 0.10, 95%CI -0.08 to 0.28) or without (SMD = -0.03, 95%CI -0.1 to 0.04) significant cognitive impairment. This was irrespective of study duration (SMD = 0.05, 95%CI -0.10 to 0.20 and SMD = 0, 95%CI -0.08 to 0.08), study size (SMD = 0.05, 95%CI -0.09 to 0.19 and SMD = -0.02, 95%CI -0.10 to 0.05), and whether participants came from countries with low folate status (SMD = 0.14, 95%CI -0.12 to 0.40 and SMD = -0.10, 95%CI -0.23 to 0.04). Supplementation of vitamins B12, B6, and folic acid alone or in combination does not appear to improve cognitive function in individuals with or without existing cognitive impairment. It remains to be established if prolonged treatment with B-vitamins can reduce the risk of dementia in later life.

### 5. MED-4929 · Vitamins E and C in the Prevention of Cardiovascular Disease in Men: The Physicians’ Health Study II Randomized Trial

Context Basic and observational studies suggest vitamins E or C may reduce risk of cardiovascular disease (CVD). However, few long-term trials have evaluated men at initially low risk of CVD, and no previous trial in men has examined vitamin C alone in the prevention of CVD. Objective To test whether long-term vitamin E or C supplementation decreases risk of major cardiovascular events among men. Design, Setting, and Participants The Physicians’ Health Study II (PHS II) is a randomized, double-blind, placebo-controlled factorial trial of vitamins E and C that began in 1997 and continued until its scheduled completion on August 31, 2007. We enrolled 14,641 U.S. male physicians initially aged ≥50 years, including 754 (5.1%) men with prevalent CVD at randomization. Intervention Individual supplements of 400 IU vitamin E every other day and 500 mg vitamin C daily. Main Outcome Measures A composite endpoint of major cardiovascular events (nonfatal myocardial infarction (MI), nonfatal stroke, and CVD death). Results During a mean follow-up of 8.0 years, there were 1,245 confirmed major cardiovascular events. Compared with placebo, vitamin E had no effect on the incidence of major cardiovascular events (both active and placebo vitamin E groups, 10.9 events per 1,000 person-years; hazard ratio \[HR\], 1.01; 95% confidence interval \[CI\], 0.90–1.13; P=0.86), as well as total MI (HR, 0.90; 95% CI, 0.75–1.07; P=0.22), total stroke (HR, 1.07; 95% CI, 0.89–1.29; P=0.45), and cardiovascular mortality (HR, 1.07; 95% CI, 0.90–1.29; P=0.43). There was also no significant effect of vitamin C on major cardiovascular events (active and placebo vitamin E groups, 10.8 and 10.9 events per 1,000 person-years, respectively; HR, 0.99; 95% CI, 0.89–1.11; P=0.91), as well as total MI (HR, 1.04; 95% CI, 0.87–1.24; P=0.65), total stroke (HR, 0.89; 95% CI, 0.74–1.07; P=0.21), and cardiovascular mortality (HR, 1.02; 95% CI, 0.85–1.21; P=0.86). Neither vitamin E (HR, 1.07; 95% CI, 0.97–1.18; P=0.15) nor vitamin C (HR, 1.07; 95% CI, 0.97–1.18; P=0.16) had a significant effect on total mortality, but vitamin E was associated with an increased risk of hemorrhagic stroke (HR, 1.74; 95% CI, 1.04–2.91; P=0.036). Conclusions In this large, long-term trial of male physicians, neither vitamin E nor C supplementation reduced the risk of major cardiovascular events. These data provide no support for the use of these supplements for the prevention of CVD in middle-aged and older men.

---

<a id="r04"></a>

## R04 · PLAIN-153 · How Should I Take Probiotics?

Mesmos documentos de [R02](#r02): MED-3679, MED-3692, MED-3695, MED-3693, MED-3680.

---

<a id="r05"></a>

## R05 · PLAIN-2750 · Preventing the Common Cold with Probiotics?

Contexto: MED-3683, MED-3695, MED-3680, MED-3690, MED-4762 · cerca de 1700 palavras · também usado em: [R18](#r18)

### 1. MED-3683 · Randomised, double-blind and placebo-controlled study using new probiotic lactobacilli for strengthening the body immune defence against viral infe...

**BACKGROUND:** The aim of this study was to investigate whether consumption of Lactobacillus plantarum HEAL 9 (DSM 15312) and Lactobacillus paracasei 8700:2 (DSM 13434) could affect naturally acquired common cold infections in healthy subjects.

**METHODS:** A randomised, parallel, double-blind placebo-controlled study was performed to investigate whether intake of this probiotic mixture could reduce the risk of common cold episodes, number of days with common cold symptoms, frequency and severity of symptoms, and cellular immune response in common cold infections. A total of 272 subjects were supplemented daily with either 10(9) cfu (colony forming units) of probiotics (N = 135) or control (N = 137) for a 12-week period.

**RESULTS:** The incidence of acquiring one or more common cold episode was reduced from 67% in the control group to 55% in the probiotic group (p < 0.05). Also, the number of days with common cold symptoms were significantly (p < 0.05) reduced from 8.6 days in the control group to 6.2 days, in the probiotic group, during the 12-week period. The total symptom score was reduced during the study period from a mean of 44.4 for the control group to 33.6 for the probiotic group. The reduction in pharyngeal symptoms was significant (p < 0.05). In addition, the proliferation of B lymphocytes was significantly counteracted in the probiotic group (p < 0.05) in comparison with the control group.

**CONCLUSION:** In conclusion, intake of the probiotic strains Lactobacillus plantarum HEAL 9 (DSM 15312) and Lactobacillus paracasei 8700:2 (DSM 13434) reduces the risk of acquiring common cold infections.

### 2. MED-3695 · Probiotics for the prevention of pediatric antibiotic-associated diarrhea.

**BACKGROUND:** Antibiotics alter the microbial balance within the gastrointestinal tract. Probiotics may prevent antibiotic-associated diarrhea (AAD) via restoration of the gut microflora. Antibiotics are prescribed frequently in children and AAD is common in this population.

**OBJECTIVES:** To assess the efficacy and adverse effects of probiotics (any specified strain or dose) for the prevention of antibiotic-associated diarrhea in children. To assess adverse events associated with the use of probiotics when co-administered with antibiotics in children.

**SEARCH STRATEGY:** MEDLINE, EMBASE, CENTRAL, CINAHL , AMED, and the Web of Science (inception to August 2006) were searched along with specialized registers including the Cochrane IBD/FBD Review Group, CISCOM, Chalmers PedCAM Research Register and trial registries from inception to 2005. Letters were sent to authors of included trials, nutra/pharmaceutical companies, and experts in the field requesting additional information on ongoing or unpublished trials. Conference proceedings, dissertation abstracts, and reference lists from included and relevant articles were hand searched.

**SELECTION CRITERIA:** Randomized, parallel, controlled (placebo, active, or no treatment) trials comparing co-administered probiotics with antibiotics for the prevention of diarrhea secondary to antibiotic use in children (0 to 18 years).

**DATA COLLECTION AND ANALYSIS:** Methodological quality assessment and data extraction were conducted independently by two authors (BCJ, AS). Dichotomous data (incidence of diarrhea, adverse events) were combined using pooled relative risks, and continuous data (mean duration of diarrhea, mean daily stool frequency) as weighted mean differences, along with their corresponding 95% confidence intervals. Adverse events were summarized using risk difference. For overall pooled results on the incidence of diarrhea, a priori sensitivity analyses included per protocol versus intention to treat, random versus fixed effects, and methodological quality criterion. Subgroup analysis were conducted on probiotic strain, dose, definition of antibiotic-associated diarrhea, and antibiotic agent.

**MAIN RESULTS:** Ten studies met the inclusion criteria. Trials included treatment with either Lactobacilli spp., Bifidobacterium spp., Streptococcus spp., or Saccharomyces boulardii alone or in combination. Six studies used a single strain probiotic agent and four combined two probiotic strains. The per protocol analysis for 9/10 trials reporting on the incidence of diarrhea show statistically significant results favouring probiotics over active/non active controls (RR 0.49; 95% CI 0.32 to 0.74). However, intention to treat analysis showed non-significant results overall (RR 0.90; 95% CI 0.50 to 1.63). Five of ten trials monitored for adverse events (n = 647); none reported a serious adverse event.

**AUTHORS' CONCLUSIONS:** Probiotics show promise for the prevention of pediatric AAD. While per protocol analysis yields treatment effect estimates that are both statistically and clinically significant, as does analysis of high quality studies, the estimate from the intention to treat analysis was not statistically significant. Future studies should involve probiotic strains and doses with the most promising evidence (e.g., Lactobacillus GG, Lactobacillus sporogenes, Saccharomyces boulardii at 5 to 40 billion colony forming units/day). Research done to date does not permit determination of the effect of age (e.g., infant versus older children) or antibiotic duration (e.g., 5 days versus 10 days). Future trials would benefit from a validated primary outcome measure for antibiotic-associated diarrhea that is sensitive to change and reflects what treatment effect clinicians, parents, and children consider important. The current data are promising, but it is premature to routinely recommend probiotics for the prevention of pediatric AAD.

### 3. MED-3680 · Probiotics for preventing acute upper respiratory tract infections.

**BACKGROUND:** Probiotics may improve a person's health by regulating their immune function. Some studies show that probiotic strains can prevent respiratory infections. However, no evidence of the benefits of probiotics for acute upper respiratory tract infections (URTIs) and related potential adverse effects has been published.

**OBJECTIVES:** To assess the effectiveness and safety of probiotics for preventing acute URTIs.

**SEARCH STRATEGY:** We searched the Cochrane Central Register of Controlled Trials (CENTRAL) (The Cochrane Library 2011, Issue 2), which includes the Cochrane Acute Respiratory Infections Group's Specialised Register, MEDLINE (Ovid) (1950 to May week 1, 2011), EMBASE (1974 to May 2011), Web of Science which includes Science Citation Index (from 1900 to May 2011) and Conference Proceedings Citation Index (from 1991 to May 2011), the Chinese Biomedical Literature Database, which includes the China Biological Medicine Database (from 1978 to May 2011), the Chinese Medicine Popular Science Literature Database (from 2000 to May 2011) and the Masters Degree Dissertation of Beijing Union Medical College Database (from 1981 to May 2011).

**SELECTION CRITERIA:** Randomised controlled trials (RCTs) comparing probiotics with placebo to prevent acute URTIs.

**DATA COLLECTION AND ANALYSIS:** Two review authors independently assessed eligibility, quality of trials and extracted data.

**MAIN RESULTS:** We included 14 RCTs, although we could only extract available data to meta-analyse in 10 trials which involved 3451 participants. We found that probiotics were better than placebo when measuring the number of participants experiencing episodes of acute URTI: at least one episode: odds ratio (OR) 0.58; 95% confidence interval (CI) 0.36 to 0.92; at least three episodes: OR 0.53; 95% CI 0.36 to 0.80; rate ratio of episodes of acute URTI: rate ratio 0.88; 95% CI 0.81 to 0.96; and reduced antibiotic prescription rates for acute URTIs: OR 0.67; 95% CI 0.45 to 0.98. Probiotics and placebo were similar when measuring the mean duration (MD) of an episode of acute URTI: MD -0.29; 95% CI -3.71 to 3.13 and adverse events: OR 0.92; 95% CI 0.37 to 2.28. Side effects of probiotics were minor and gastrointestinal symptoms were the most common. We found that some subgroups had a high level of heterogeneity when conducting pooled analyses.

**AUTHORS' CONCLUSIONS:** Probiotics were better than placebo in reducing the number of participants experiencing episodes of acute URTIs, the rate ratio of episodes of acute URTI and reducing antibiotic use. This indicates that probiotics may be more beneficial than placebo for preventing acute URTIs. However, the results have some limitations and there were no data for older people.

### 4. MED-3690 · Probiotics as prevention and treatment for diarrhea.

**PURPOSE OF REVIEW:** To critically appraise evidence on probiotic use for prevention and treatment of diarrhea in children and adults.

**RECENT FINDINGS:** Several randomized controlled trials and meta-analyses suggested that probiotics are effective in primary and secondary prevention of gastroenteritis and its treatment. Selected Lactobacillus strains had a modest, although significant effect in primary prevention. Saccharomyces boulardii was effective in antibiotic-associated and in Clostridium difficile diarrhea. There is evidence that it might prevent diarrhea in day-care centers. Lactobacillus rhamnosus GG was associated with reduced diarrheal duration and severity, more evident in case of childhood Rotavirus diarrhea. Similar, although weaker, evidence was obtained with S. boulardii. Both strains are included in evidence-based recommendations for gastroenteritis management in children. Data on other Lactobacillus strains are preliminary. Probiotic efficacy was related to cause, early administration and bacterial load, and their mechanisms were associated with antiinfectious action in the intestine or, indirectly, to modulation of innate and adaptive immunity.

**SUMMARY:** Probiotics have gained a role as adjunctive treatment of infantile gastroenteritis together with rehydration. Their efficacy is less convincing in adults, but promising in antibiotic-associated diarrhea. However, evidence of efficacy is limited to a few strains.

### 5. MED-4762 · Probiotic effects on cold and influenza-like symptom incidence and duration in children.

**OBJECTIVE:** Probiotic consumption effects on cold and influenza-like symptom incidence and duration were evaluated in healthy children during the winter season.

**METHODS:** In this double-blind, placebo-controlled study, 326 eligible children (3-5 years of age) were assigned randomly to receive placebo (N = 104), Lactobacillus acidophilus NCFM (N = 110), or L acidophilus NCFM in combination with Bifidobacterium animalis subsp lactis Bi-07 (N = 112). Children were treated twice daily for 6 months.

**RESULTS:** Relative to the placebo group, single and combination probiotics reduced fever incidence by 53.0% (P = .0085) and 72.7% (P = .0009), coughing incidence by 41.4% (P = .027) and 62.1% (P = .005), and rhinorrhea incidence by 28.2% (P = .68) and 58.8% (P = .03), respectively. Fever, coughing, and rhinorrhea duration was decreased significantly, relative to placebo, by 32% (single strain; P = .0023) and 48% (strain combination; P < .001). Antibiotic use incidence was reduced, relative to placebo, by 68.4% (single strain; P = .0002) and 84.2% (strain combination; P < .0001). Subjects receiving probiotic products had significant reductions in days absent from group child care, by 31.8% (single strain; P = .002) and 27.7% (strain combination; P < .001), compared with subjects receiving placebo treatment.

**CONCLUSION:** Daily dietary probiotic supplementation for 6 months was a safe effective way to reduce fever, rhinorrhea, and cough incidence and duration and antibiotic prescription incidence, as well as the number of missed school days attributable to illness, for children 3 to 5 years of age.

---

<a id="r06"></a>

## R06 · PLAIN-2470 · Is Milk Good for Our Bones?

Contexto: MED-1337, MED-1340, MED-1338, MED-904, MED-4902 · cerca de 1485 palavras · também usado em: [R10](#r10)

### 1. MED-1337 · Milk intake and risk of hip fracture in men and women: a meta-analysis of prospective cohort studies.

Milk contains calcium, phosphorus, and protein and is fortified with vitamin D in the United States. All these ingredients may improve bone health. However, the potential benefit of milk on hip fracture prevention is not well established. The objective of this study was to assess the association of milk intake with risk of hip fracture based on a meta-analysis of cohort studies in middle-aged or older men and women. Data sources for this study were English and non-English publications via Medline (Ovid, PubMed) and EMBASE search up to June 2010, experts in the field, and reference lists. The idea was to compare prospective cohort studies on the same scale so that we could calculate the relative risk (RR) of hip fracture per glass of milk intake daily (approximately 300 mg calcium per glass of milk). Pooled analyses were based on random effects models. The data were extracted by two independent observers. The results show that in women (6 studies, 195,102 women, 3574 hip fractures), there was no overall association between total milk intake and hip fracture risk (pooled RR per glass of milk per day = 0.99; 95% confidence interval \[CI\] 0.96-1.02; Q-test p = .37). In men (3 studies, 75,149 men, 195 hip fractures), the pooled RR per daily glass of milk was 0.91 (95% CI 0.81-1.01). Our conclusion is that in our meta-analysis of cohort studies, there was no overall association between milk intake and hip fracture risk in women but that more data are needed in men. Copyright © 2011 American Society for Bone and Mineral Research.

### 2. MED-1340 · Milk Consumption During Teenage Years and Risk of Hip Fractures in Older Adults

Importance Milk consumption during adolescence is recommended to promote peak bone mass and thereby reduce fracture risk in later life. However, its role in hip fracture prevention is not established and high consumption may adversely influence risk by increasing height. Objective To determine whether milk consumption during teenage years influences risk of hip fracture in older adults and to investigate the role of attained height in this association. Design Prospective cohort study over 22 years of follow-up Setting United States Participants Over 96,000 Caucasian postmenopausal women from the Nurses’ Health Study and men age 50 and older from the Health Professionals Follow-up Study Exposures Frequency of consumption of milk and other foods during ages 13–18 and attained height were reported at baseline. Current diet, weight, smoking, physical activity, medication use, and other risk factors for hip fractures were reported on biennial questionnaires. Main Outcome Measures Cox proportional hazards models were used to calculate relative risks (RR) of first incident hip fracture from low-trauma events per glass (8 fl oz or 240 mL) of milk consumed per day during teenage years. Results Over follow-up, 1226 hip fractures were identified in women and 490 in men. After controlling for known risk factors and current milk consumption, each additional glass of milk per day during teenage years was associated with a significant 9% higher risk of hip fracture in men (RR=1.09, 95% CI 1.01–1.17). The association was attenuated when height was added to the model (RR=1.06, 95% CI 0.98–1.14). Teenage milk consumption was not associated with hip fractures in women (RR=1.00, 95% CI 0.95–1.05 per glass per day). Conclusion and Relevance Greater milk consumption during teenage years was not associated with a lower risk of hip fracture in older adults. The positive association observed in men was partially mediated through attained height.

### 3. MED-1338 · Milk intake and risk of mortality and fractures in women and men: cohort studies

Objective To examine whether high milk consumption is associated with mortality and fractures in women and men. Design Cohort studies. Setting Three counties in central Sweden. Participants Two large Swedish cohorts, one with 61 433 women (39-74 years at baseline 1987-90) and one with 45 339 men (45-79 years at baseline 1997), were administered food frequency questionnaires. The women responded to a second food frequency questionnaire in 1997. Main outcome measure Multivariable survival models were applied to determine the association between milk consumption and time to mortality or fracture. Results During a mean follow-up of 20.1 years, 15 541 women died and 17 252 had a fracture, of whom 4259 had a hip fracture. In the male cohort with a mean follow-up of 11.2 years, 10 112 men died and 5066 had a fracture, with 1166 hip fracture cases. In women the adjusted mortality hazard ratio for three or more glasses of milk a day compared with less than one glass a day was 1.93 (95% confidence interval 1.80 to 2.06). For every glass of milk, the adjusted hazard ratio of all cause mortality was 1.15 (1.13 to 1.17) in women and 1.03 (1.01 to 1.04) in men. For every glass of milk in women no reduction was observed in fracture risk with higher milk consumption for any fracture (1.02, 1.00 to 1.04) or for hip fracture (1.09, 1.05 to 1.13). The corresponding adjusted hazard ratios in men were 1.01 (0.99 to 1.03) and 1.03 (0.99 to 1.07). In subsamples of two additional cohorts, one in males and one in females, a positive association was seen between milk intake and both urine 8-iso-PGF2α (a biomarker of oxidative stress) and serum interleukin 6 (a main inflammatory biomarker). Conclusions High milk intake was associated with higher mortality in one cohort of women and in another cohort of men, and with higher fracture incidence in women. Given the observational study designs with the inherent possibility of residual confounding and reverse causation phenomena, a cautious interpretation of the results is recommended.

### 4. MED-904 · A systematic review and meta-analysis of the effects of pasteurization on milk vitamins, and evidence for raw milk consumption and other health-rel...

Pasteurization of milk ensures safety for human consumption by reducing the number of viable pathogenic bacteria. Although the public health benefits of pasteurization are well established, pro-raw milk advocate organizations continue to promote raw milk as "nature's perfect food." Advocacy groups' claims include statements that pasteurization destroys important vitamins and that raw milk consumption can prevent and treat allergies, cancer, and lactose intolerance. A systematic review and meta-analysis was completed to summarize available evidence for these selected claims. Forty studies assessing the effects of pasteurization on vitamin levels were found. Qualitatively, vitamins B12 and E decreased following pasteurization, and vitamin A increased. Random effects meta-analysis revealed no significant effect of pasteurization on vitamin B6 concentrations (standardized mean difference \[SMD\], -2.66; 95% confidence interval \[CI\], -5.40, 0.8; P = 0.06) but a decrease in concentrations of vitamins B1 (SMD, -1.77; 95% CI, -2.57, -0.96; P < 0.001), B2 (SMD, -0.41; 95% CI, -0.81, -0.01; P < 0.05), C (SMD, -2.13; 95% CI, -3.52, -0.74; P < 0.01), and folate (SMD, -11.99; 95% CI, -20.95, -3.03; P < 0.01). The effect of pasteurization on milk's nutritive value was minimal because many of these vitamins are naturally found in relatively low levels. However, milk is an important dietary source of vitamin B2, and the impact of heat treatment should be further considered. Raw milk consumption may have a protective association with allergy development (six studies), although this relationship may be potentially confounded by other farming-related factors. Raw milk consumption was not associated with cancer (two studies) or lactose intolerance (one study). Overall, these findings should be interpreted with caution given the poor quality of reported methodology in many of the included studies.

### 5. MED-4902 · Addition of milk prevents vascular protective effects of tea.

**AIMS:** Experimental and clinical studies indicate that tea exerts protection against cardiovascular diseases. However, a question of much debate is whether addition of milk modifies the biological activities of tea. We studied the vascular effects of tea, with or without milk, in humans and elucidated the impact of individual milk proteins in cell culture experiments, with isolated rat aortic rings and by HPLC analysis.

**METHODS AND RESULTS:** A total of 16 healthy female volunteers consumed either 500 mL of freshly brewed black tea, black tea with 10% skimmed milk, or boiled water as control. Flow-mediated dilation (FMD) was measured by high-resolution vascular ultrasound before and 2 h after consumption. Black tea significantly improved FMD in humans compared with water, whereas addition of milk completely blunted the effects of tea. To support these findings, similar experiments were performed in isolated rat aortic rings and endothelial cells. Tea induced vasorelaxation in rat aortic rings and increased the activity of endothelial nitric oxide synthase by phosphorylation of the enzyme in endothelial cells. All effects were completely inhibited by the addition of milk to tea. Of the various kinds of milk proteins, the caseins accounted for these inhibiting effects of milk, probably by formation of complexes with tea catechins.

**CONCLUSION:** Milk counteracts the favourable health effects of tea on vascular function. This finding indicates the need for particular awareness in the interpretation and design of studies comprising nutritional flavonoids.

---

<a id="r07"></a>

## R07 · PLAIN-2430 · Preventing Brain Loss with B Vitamins?

Mesmos documentos de [R03](#r03): MED-994, MED-980, MED-5128, MED-986, MED-4929.

---

<a id="r08"></a>

## R08 · PLAIN-3342 · Is Coconut Milk Good For You?

Mesmos documentos de [R01](#r01): MED-5014, MED-5015, MED-4000, MED-4002, MED-5012.

---

<a id="r09"></a>

## R09 · PLAIN-2850 · More Antibiotics In White Meat or Dark Meat?

Contexto: MED-3891, MED-4358, MED-4983, MED-2584, MED-4482 · cerca de 1429 palavras · também usado em: [R17](#r17)

### 1. MED-3891 · Comparison of the Prevalences and Antimicrobial Resistances of Escherichia coli Isolates from Different Retail Meats in the United States, 2002 to 2008

Escherichia coli isolates were recovered from the National Antimicrobial Resistance Monitoring System retail meat program and examined for antimicrobial susceptibility. Retail meat samples (n = 11,921) from four U.S. states collected during 2002 to 2008, consisting of 2,988 chicken breast, 2,942 ground turkey, 2,991 ground beef, and 3,000 pork chop samples, were analyzed. A total of 8,286 E. coli isolates were recovered. The greatest numbers of samples contaminated with the organism were chicken (83.5%) and turkey (82.0%), followed by beef (68.9%) and pork (44.0%). Resistance was most common to tetracycline (50.3%), followed by streptomycin (34.6%), sulfamethoxazole-sulfisoxazole (31.6%), ampicillin (22.5%), gentamicin (18.6%), kanamycin (8.4%), amoxicillin-clavulanic acid (6.4%), and cefoxitin (5.2%). Less than 5% of the isolates had resistance to trimethoprim, ceftriaxone, ceftiofur, nalidixic acid, chloramphenicol, and ciprofloxacin. All isolates were susceptible to amikacin. Compared to beef and pork isolates, the poultry meat isolates had a greater percentage of resistance to all tested drugs, with the exception of chloramphenicol, to which pork isolates had the most resistance. More than half of the turkey isolates (56%) were resistant to multidrugs (≥3 classes) compared to 38.9% of chicken, 17.3% of pork, and 9.3% of beef isolates. The blaCMY gene was present in all ceftriaxone- and ceftiofur-resistant isolates. The cmlA, flo, and catI genes were present in 45%, 43%, and 40% of chloramphenicol-resistant isolates, respectively. Most nalidixic acid-resistant isolates (98.5%) had a gyrA mutation in S83 or D87 or both, whereas only 6.7% had a parC mutation in either S80 or E84. The results showed that E. coli was commonly present in the retail meats, and antimicrobial resistance profiles differed according to the animal origin of the isolates.

### 2. MED-4358 · Bacteriophage biocontrol in animals and meat products

Summary Since their discovery almost a century ago, bacterial viruses (bacteriophages or ‘phages’) have been used to prevent and treat a multitude of bacterial infections (phage therapy: PT). In addition, they have been the basis for many advances in genetics and biochemistry. Phage therapy was performed on human subjects in the United States, Europe and Asia in the few decades following their discovery. However, Western countries largely abandoned PT in favour of antibiotics in the 1940s. The relatively recent renaissance of PT in the West can be attributed partly to the increasing prevalence of antibiotic resistance in human and animal pathogens. However, the stringent controls on human trials now required in the United States and Europe have led to a greater number of domestic animal and agricultural applications as an alternative to PT in man. This trend is set to continue, at least in the short term, with recent approval from the Food and Drug Administration allowing commercial phage treatments to be used in human food in the USA. Nevertheless, despite these significant milestones and the growing number of successful PT trials, significant obstacles remain to their widespread use in animals, food and ultimately medicine in many parts of the world. This review will provide a brief overview of the history of PT in the West and will summarize some of the key findings of phage biocontrol studies in animals and meat products.

### 3. MED-4983 · Meat intake and mortality: a prospective study of over half a million people

Context High intakes of red or processed meat may increase risk of mortality. Objective Determine the relations of red, white and processed meat intakes to risk for total, and cause-specific mortality. Design, Setting, and Participants The NIH-AARP Diet and Health Study cohort of half a million people aged 50-71 years at baseline. Meat intake was estimated from a food frequency questionnaire administered at baseline. Cox proportional hazards regression estimated hazard ratios (HRs) and 95% confidence intervals (CIs) within quintiles of meat intake. The covariates included in the models were: age; education; marital status; family history of cancer (yes/no) (cancer mortality only); race; body mass index; 31-level smoking history; physical activity; energy intake; alcohol intake; vitamin supplement use; fruit consumption; vegetable consumption; and menopausal hormone therapy among women. Main Outcome Measure Total mortality, deaths due to cancer, CVD, accidents, and other causes. Results There were 47,976 male deaths and 23,276 female deaths during 10 years of follow-up. Men and women in the highest versus lowest quintile of red (HR 1.31, 95% CI 1.27-1.35; HR 1.36, 95% CI 1.30-1.43, respectively) and processed meat intake (HR 1.16, 95% CI 1.12-1.20; HR 1.25, 95% 1.20-1.31, respectively) had elevated risks for overall mortality. Regarding cause-specific mortality, men and women had elevated risks for cancer mortality for red (HR 1.22, 95% CI 1.16-1.29; HR 1.20, 95% CI 1.12-1.30, respectively) and processed meats (HR 1.12, 95% CI 1.06-1.19; HR 1.11, 95% CI 1.04-1.19, respectively). Furthermore, CVD risk was elevated for men and women in the highest quintile of red (HR 1.27, 95% CI 1.20-1.35; HR 1.50, 95% CI 1.37-1.65, respectively) and processed meat (HR 1.09, 95% CI 1.03-1.15; HR 1.38, 95% CI 1.26-1.51, respectively). When comparing the highest to the lowest quintile of white meat intake, there was an inverse association for total mortality, and cancer mortality, as well as all other deaths for both men and women. Conclusion Red and processed meat intakes were associated with modest increases in total mortality, cancer mortality and CVD mortality.

### 4. MED-2584 · Dietary risk factors for colon cancer in a low-risk population.

In a 6-year prospective study, the authors examined the relation between diet and incident colon cancer among 32,051 non-Hispanic white cohort members of the Adventist Health Study (California, 1976-1982) who, at baseline, had no documented or reported history of cancer. The risk of colon cancer was determined from proportional hazards regression with adjustment for age and other covariates. The authors found a positive association with total meat intake (risk ratio (RR) for > or =1 time/week vs. no meat intake = 1.85, 95% confidence interval (CI) 1.19-2.87; p for trend = 0.01) and, among subjects who favored specific types of meat, positive associations with red meat intake (RR for > or =1 time/week vs. no red meat intake = 1.90, 95% CI 1.16-3.11; p for trend = 0.02) and white meat intake (RR for > or =1 time/week vs. no white meat intake = 3.29, 95% CI 1.60-6.75; p for trend = 0.006). An inverse association with legume intake (RR for >2 times/week vs. <1 time/week = 0.53, 95% CI 0.33-0.86; p for trend = 0.03) was observed. Among men, a positive association with body mass index was observed (relative to the RR for tertile III (>25.6 kg/m2) vs. tertile I (<22.5 kg/m2) = 2.63, 95% CI 1.12-6.13; p for trend = 0.05). A complex relation was identified whereby subjects exhibiting a high red meat intake, a low legume intake, and a high body mass experienced a more than threefold elevation in risk relative to all other patterns based on these variables. This pattern of putative risk factors would likely contribute to increases in both insulin resistance (high body mass, high red meat intake) and glycemic load (low legume intake), a synergism that, if causal, implicates hyperinsulinemic exposure in colon carcinogenesis. The overall findings from this cohort identify both red meat intake and white meat intake as important dietary risk factors for colon cancer and raise the possibility that the risk due to red meat intake reflects a more complex etiology.

### 5. MED-4482 · Meat consumption, Cooking Practices, Meat Mutagens and Risk of Prostate Cancer

Consumption of red meat, particularly well done meat, has been associated with increased prostate cancer risk. High temperature cooking methods such as grilling and barbequeing may produce heterocyclic amines (HCAs) and polycyclic aromatic hydrocarbons (PAHs) which are known carcinogens. We assessed the association with meat consumption and estimated HCA and PAH exposure in a population-based case-control study of prostate cancer. Newly diagnosed cases aged 40–79 years (531 advanced cases, 195 localized cases) and 527 controls were asked about dietary intake, including usual meat cooking methods and doneness levels. Odds ratios (OR) and 95% confidence intervals (CI) were calculated using multivariate logistic regression. For advanced prostate cancer, but not localized disease, increased risks were associated with higher consumption of hamburgers (OR=1.79. CI=1.10–2.92), processed meat (OR=1.57, CI=1.04, 2.36), grilled red meat (OR=1.63, CI=0.99–2.68), and well done red meat (OR=1.52, CI=0.93–2.46), and intermediate intake of 2-amino-1-methyl1-6-phenylimidazo\[4,5-b\]pyridine (PhIP) (quartile 2 vs. 1: OR=1.41, CI=0.98–2.01; quartile 3 vs. 1: OR=1.42, CI=0.98–2.04), but not for higher intake. White meat consumption was not associated with prostate cancer. These findings provide further evidence that consumption of processed meat and red meat cooked at high temperature is associated with increased risk of advanced, but not localized prostate cancer.

---

<a id="r10"></a>

## R10 · PLAIN-2470 · Is Milk Good for Our Bones?

Mesmos documentos de [R06](#r06): MED-1337, MED-1340, MED-1338, MED-904, MED-4902.

---

<a id="r11"></a>

## R11 · PLAIN-238 · How Chemically Contaminated Are We?

Contexto: MED-2391, MED-4739, MED-2493, MED-4653, MED-2994 · cerca de 923 palavras · também usado em: [R16](#r16)

### 1. MED-2391 · Perfluorinated Compounds, Polychlorinated Biphenyls, and Organochlorine Pesticide Contamination in Composite Food Samples from Dallas, Texas, USA

Objectives The objective of this article is to extend our previous studies of persistent organic pollutant (POP) contamination of U.S. food by measuring perfluorinated compounds (PFCs), organochlorine pesticides, and polychlorinated biphenyls (PCBs) in composite food samples. This study is part of a larger study reported in two articles, the other of which reports levels of polybrominated diphenyl ethers and hexabromocyclododecane brominated flame retardants in these composite foods \[Schecter et al. 2010. Polybrominated diphenyl ethers (PBDEs) and hexabromocyclodecane (HBCD) in composite U.S. food samples, Environ Health Perspect 118:357–362\]. Methods In this study we measured concentrations of 32 organochlorine pesticides, 7 PCBs, and 11 PFCs in composite samples of 31 different types of food (310 individual food samples) purchased from supermarkets in Dallas, Texas (USA), in 2009. Dietary intake of these chemicals was calculated for an average American. Results Contamination varied greatly among chemical and food types. The highest level of pesticide contamination was from the dichlorodiphenyltrichloroethane (DDT) metabolite p,p′- dichlorodiphenyldichloroethylene, which ranged from 0.028 ng/g wet weight (ww) in whole milk yogurt to 2.3 ng/g ww in catfish fillets. We found PCB congeners (28, 52, 101, 118, 138, 153, and 180) primarily in fish, with highest levels in salmon (PCB-153, 1.2 ng/g ww; PCB-138, 0.93 ng/g ww). For PFCs, we detected perfluorooctanoic acid (PFOA) in 17 of 31 samples, ranging from 0.07 ng/g in potatoes to 1.80 ng/g in olive oil. In terms of dietary intake, DDT and DDT metabolites, endosulfans, aldrin, PCBs, and PFOA were consumed at the highest levels. Conclusion Despite product bans, we found POPs in U.S. food, and mixtures of these chemicals are consumed by the American public at varying levels. This suggests the need to expand testing of food for chemical contaminants.

### 2. MED-4739 · Nowhere to hide: Chemical toxicants and the unborn child.

Contemporary reproductive aged women and their offspring are facing an unprecedented onslaught of toxicant exposures from myriad sources in their day-to-day life. Public health recommendations regarding optimal diet and nutrition in pregnancy must incorporate several considerations including safety of available foodstuffs, cultural practices and lifestyle issues. Gestational consumption of contaminated seafood remains a potential source of toxicant exposure, including mercury, for the developing child. Health care professionals responsible for the care of women and their developing children need to become apprised of: a) risks associated with toxicant bioaccumulation in pregnancy; b) ongoing information emerging in the important field of reproductive toxicology; and c) strategies within the clinical setting to facilitate nutritional sufficiency and precautionary avoidance of adverse exposure among young women.

### 3. MED-2493 · Environmental toxicants and the developing immune system: a missing link in the global battle against infectious disease?

There is now compelling evidence that developmental exposure to chemicals from our environment contributes to disease later in life, with animal models supporting this concept in reproductive, metabolic, and neurodegenerative diseases. In contrast, data regarding how developmental exposures impact the susceptibility of the immune system to functional alterations later in life are surprisingly scant. Given that the immune system forms an integrated network that detects and destroys invading pathogens and cancer cells, it provides the body’s first line of defense. Thus, the consequences of early-life exposures that reduce immune function are profound. This review summarizes available data for pollutants such as cigarette smoke and dioxin-like compounds, which consistently support the idea that developmental exposures critically impact the immune system. These findings suggest that exposure to common chemicals from our daily environment represent overlooked contributors to the fact that infectious diseases remain among the top five causes of death worldwide.

### 4. MED-4653 · Dietary Intake Is Associated with Phthalate Body Burden in a Nationally Representative Sample

Background Phthalates are compounds that are used in a wide range of consumer products. However, the contribution of dietary intake to phthalate exposure has not been well defined. Objective The objective of this study was to assess the contribution of different food types to phthalate exposure. Phthalates are chemicals of concern because of the high levels measured in people and the environment, as well as the demonstrated toxicity in animal studies and limited epidemiological studies. Previous research, although limited, has suggested that phthalates contaminate food in various countries. Methods We conducted an exploratory analysis of data collected as part of the 2003–2004 National Health and Nutrition Examination Survey (NHANES). Associations between dietary intake (assessed by a 24-hr dietary recall) for a range of food types (meat, poultry, fish, fruit, vegetable, and dairy) and phthalate metabolites measured in urine were analyzed using multiple linear regression modeling. Results We found that metabolites of di-(2-ethylhexyl) phthalate (DEHP) and high-molecular-weight phthalate metabolites were associated with the consumption of poultry. Monoethyl phthalate, the metabolite of diethyl phthalate (DEP), was associated with vegetable consumption, specifically tomato and potato consumption. Discussion These results, combined with results from previous studies, suggest that diet is an important route of intake for phthalates. Further research is needed to determine the sources of food contamination with these toxic chemicals and to describe the levels of contamination of U.S. food in a large, representative U.S. sample.

### 5. MED-2994 · Carcinogenicity and regulation of caramel colorings.

2- and 4-methylimidazoles are present as contaminants in caramel colorings manufactured with ammonia catalysts. Both contaminants have been shown to induce cancer in animals and may be present in caramel colorings in amounts that exceed federal guidelines. California requires warning notices on products that could lead to consumption of more than 30 micrograms per day. The US Food and Drug Administration should bar the use of excessively contaminated caramel coloring in food.

---

<a id="r12"></a>

## R12 · PLAIN-270 · Is Caffeinated Tea Really Dehydrating?

Contexto: MED-4331, MED-5245, MED-878, MED-1645, MED-4439 · cerca de 1286 palavras · também usado em: [R14](#r14)

### 1. MED-4331 · Black tea is not significantly different from water in the maintenance of normal hydration in human subjects: results from a randomised controlled ...

There is a belief that caffeinated drinks, such as tea, may adversely affect hydration. This was investigated in a randomised controlled trial. Healthy resting males (n 21) were recruited from the general population. Following 24 h of abstention from caffeine, alcohol and vigorous physical activity, including a 10 h overnight fast, all men underwent four separate test days in a counter-balanced order with a 5 d washout in between. The test beverages, provided at regular intervals, were 4 × 240 ml black (i.e. regular) tea and 6 × 240 ml black tea, providing 168 or 252 mg of caffeine. The controls were identical amounts of boiled water. The tea was prepared in a standardised way from tea bags and included 20 ml of semi-skimmed milk. All food taken during the 12 h intervention period was controlled, and subjects remained at rest. No other beverages were offered. Blood was sampled at 0, 1, 2, 4, 8 and 12 h, and a 24 h urine sample was collected. Outcome variables were whole blood cell count, Na, K, bicarbonate, total protein, urea, creatinine and osmolality for blood; and total volume, colour, Na, K, creatinine and osmolality for urine. Although data for all twenty-one participants were included in the analysis (mean age 36 years and mean BMI 25·8 kg/m(2)), nineteen men completed all conditions. Statistical analysis, using a factorial ANOVA approach within PROC MIXED, revealed no significant differences between tea and water for any of the mean blood or urine measurements. It was concluded that black tea, in the amounts studied, offered similar hydrating properties to water.

### 2. MED-5245 · Effect of decaffeination of coffee or tea on gastro-oesophageal reflux.

**BACKGROUND:** Coffee and tea are believed to cause gastro-oesophageal reflux; however, the effects of these beverages and of their major component, caffeine, have not been quantified. The aim of this study was to evaluate gastro-oesophageal reflux induced by coffee and tea before and after a decaffeination process, and to compare it with water and water-containing caffeine.

**METHODS:** Three-hour ambulatory pH-metry was performed on 16 healthy volunteers, who received 300 ml of (i) regular coffee, decaffeinated coffee or tap water (n = 16), (ii) normal tea, decaffeinated tea, tap water, or coffee adapted to normal tea in caffeine concentration (n = 6), and (iii) caffeine-free and caffeine-containing water (n = 8) together with a standardized breakfast.

**RESULTS:** Regular coffee induced a significant (P < 0.05) gastro-oesophageal reflux compared with tap water and normal tea, which were not different from each other. Decaffeination of coffee significantly (P < 0.05) diminished gastro-oesophageal reflux, whereas decaffeination of tea or addition of caffeine to water had no effect. Coffee adapted to normal tea in caffeine concentration significantly (P < 0.05) increased gastro-oesophageal reflux.

**CONCLUSIONS:** Coffee, in contrast to tea, increases gastro-oesophageal reflux, an effect that is less pronounced after decaffeination. Caffeine does not seem to be responsible for gastro-oesophageal reflux which must be attributed to other components of coffee.

### 3. MED-878 · Acute effects of coffee on endothelial function in healthy subjects.

**BACKGROUND/OBJECTIVES:** Coffee is the most widely consumed beverage in the world, but its effect on the cardiovascular system has not been fully understood. Coffee contains caffeine and antioxidants, which may influence endothelial function, both of which have not yet been investigated. The objective of this study was to investigate the acute effects of coffee on endothelial function measured by brachial artery flow-mediated dilation (FMD).

**SUBJECTS/METHODS:** A total of 20 (10 males and 10 females) healthy non-obese subjects underwent a double-blind, crossover study. Subjects ingested one cup of caffeinated (CC) and one cup of decaffeinated (DC) Italian espresso coffee in random order at 5- to 7-day intervals.

**RESULTS:** Following CC ingestion, FMD decreased progressively and significantly (mean+/-s.e.m.: 0 min, 7.7+/-0.6; 30 min, 6.3+/-0.7; 60 min, 6.0+/-0.8%; ANOVA (analysis of variance), P<0.05), but it did not significantly increase after DC ingestion (0 min, 6.9+/-0.6; 30 min, 8.1+/-0.9; 60 min, 8.5+/-0.9%; P=0.115). Similarly, CC significantly increased both systolic and diastolic blood pressure; this effect was not observed after DC ingestion. Blood glucose concentrations remained unchanged after ingestion of both CC and DC, but insulin (0 min, 15.8+/-0.9; 60 min, 15.0+/-0.8 muU/ml; P<0.05) and C-peptide (0 min, 1.25+/-0.09; 60 min, 1.18+/-0.09 ng/ml; P<0.01) blood concentrations decreased significantly only after CC ingestion.

**CONCLUSIONS:** CC acutely induced unfavorable cardiovascular effects, especially on endothelial function. In the fasting state, insulin secretion is also likely reduced after CC ingestion. Future studies will determine whether CC has detrimental clinically relevant effects, especially in unhealthy subjects.

### 4. MED-1645 · The acute effect of green tea consumption on endothelial function in healthy individuals.

**BACKGROUND:** Tea consumption is associated with decreased cardiovascular risk. Flow-mediated dilatation (FMD) of the brachial artery is related to coronary endothelial function and it is an independent predictor of cardiovascular risk. Black tea has a beneficial effect on endothelial function; the effect, however, of green tea on brachial artery reactivity has not been defined yet.

**DESIGN AND METHODS:** We studied 14 healthy individuals (age 30+/-3 years) with no cardiovascular risk factors except from smoking (50%) on three separate occasions on which they took: (a) 6 g of green tea, (b) 125 mg of caffeine (the amount contained in 6 g of tea), or (c) hot water. FMD of the brachial artery was measured before each intervention and 30, 90, and 120 min afterward. High-sensitivity C-reactive protein, interleukins 6 (Il-6) and 1b (Il-1b), total plasma antioxidative capacity, and total plasma oxidative status/stress were measured at baseline and at 120 min after each intervention.

**RESULTS:** Resting and hyperemic brachial artery diameter did not change either with tea or with caffeine. FMD increased significantly with tea (by 3.69%, peak at 30 min, P<0.02), whereas it did not change significantly with caffeine (increase by 1.72%, peak at 30 min, P=NS). Neither tea nor caffeine had any effect on high-sensitivity C-reactive protein, Il-6, Il-1b, total plasma antioxidative capacity, or total plasma oxidative status/stress.

**CONCLUSION:** Green tea consumption has an acute beneficial effect on endothelial function, assessed with FMD of the brachial artery, in healthy individuals. This may be involved in the beneficial effect of tea on cardiovascular risk.

### 5. MED-4439 · A case of fatal caffeine poisoning.

Caffeine is a natural alkaloid methylxanthine that is found in various plants such as coffee or tea. Symptoms of a severe overdose may present with hypokalemia, hyponatremia, ventricular arrhythmias, hypertension followed by hypotension, respiratory failure, seizures, rhabdomyolysis, ventricular fibrillation and finally circulatory collapse. A 21-year-old woman called for the ambulance herself soon after the ingestion of about 10,000 mg of caffeine. At the arrival of the ambulance, the patient went into cardiac arrest almost immediately. After a total resuscitation period of 34 min including seven counter-shocks and 2 mg epinephrine, the patient was stable enough to be transferred to the hospital. The patient soon went into VF again and received two more counter-shocks and 1 mg epinephrine and finally an intravenous bolus dose of 300 mg amiodarone. The initial arterial blood gas showed pH at 6.47, lactate at 33 mmol/l and potassium level at 2.3 mmol/l. Unfortunately, no blood samples for caffeine analysis were taken. Three days after hospital admission, the patient developed myoclonus, which did not respond to medical treatment. Excessive intake of caffeine may produce arrhythmias and pronounced hypokalemia and ensuing ventricular fibrillation. In case of counter-shock-resistant VF, it can be necessary to give an early loading dose of amiodarone. Furthermore, it may be beneficial to replace the potassium as early as possible. Epinephrine and buffer solutions used during resuscitation may further decrease blood potassium levels and should be administrated cautiously. Epinephrine can be replaced by other vasopressor drugs, such as vasopressin without effects on beta-receptors.

---

<a id="r13"></a>

## R13 · PLAIN-68 · What is Actually in Chicken Nuggets?

Contexto: MED-2991, MED-1797, MED-2492, MED-2088, MED-1810 · cerca de 1204 palavras · também usado em: [R19](#r19)

### 1. MED-2991 · The autopsy of chicken nuggets reads "chicken little".

**PURPOSE:** To determine the contents of chicken nuggets from 2 national food chains.

**BACKGROUND:** Chicken nuggets have become a major component of the American diet. We sought to determine the current composition of this highly processed food.

**METHODS:** Randomly selected nuggets from 2 different national fast food chains were fixed in formalin, sectioned and stained for microscopic analysis.

**RESULTS:** Striated muscle (chicken meat) was not the predominate component in either nugget. Fat was present in equal or greater quantities along with epithelium, bone, nerve, and connective tissue.

**CONCLUSION:** Chicken nuggets are mostly fat, and their name is a misnomer. Copyright © 2013 Elsevier Inc. All rights reserved.

### 2. MED-1797 · Comparative genome analysis with the human genome reveals chicken genes associated with fatness and body weight.

The selection of meat-type chickens (broilers) for rapid growth has been accompanied by excessive fat deposition. In this study, we analysed 53 candidate genes that are associated with obesity and obesity-related traits in humans, for which we found chicken orthologues by BLAST searches. We have identified single nucleotide polymorphisms (SNPs) with significant differences in allele frequencies between broilers and layers in each of the following six candidate genes: adrenergic, beta-2-, receptor, surface (ADRB2); melanocortin 5 receptor (MC5R); leptin receptor (LEPR), McKusick-Kaufman syndrome (MKKS), milk fat globule-EGF factor 8 protein (MFGE8) and adenylate kinase 1 (AK1). To examine associations with fatness and/or body weight, we used birds of extreme phenotypes in F(2) and backcross populations with varying levels of abdominal fat weight per cent (%AFW) and body weight. We then assessed the level of gene expression by real-time PCR. In two genes, ADRB2 and MFGE8, we found significant association with %AFW. The ADRB2 gene was found to have a significantly higher expression in the liver of lean chickens compared with those of the fat individuals. We believe that this approach can be applied for the identification of other quantitative genes. © 2011 The Authors, Animal Genetics © 2011 Stichting International Foundation for Animal Genetics.

### 3. MED-2492 · Roxarsone, Inorganic Arsenic, and Other Arsenic Species in Chicken: A U.S.-Based Market Basket Sample

Background: Inorganic arsenic (iAs) causes cancer and possibly other adverse health outcomes. Arsenic-based drugs are permitted in poultry production; however, the contribution of chicken consumption to iAs intake is unknown. Objectives: We sought to characterize the arsenic species profile in chicken meat and estimate bladder and lung cancer risk associated with consuming chicken produced with arsenic-based drugs. Methods: Conventional, antibiotic-free, and organic chicken samples were collected from grocery stores in 10 U.S. metropolitan areas from December 2010 through June 2011. We tested 116 raw and 142 cooked chicken samples for total arsenic, and we determined arsenic species in 65 raw and 78 cooked samples that contained total arsenic at ≥ 10 µg/kg dry weight. Results: The geometric mean (GM) of total arsenic in cooked chicken meat samples was 3.0 µg/kg (95% CI: 2.5, 3.6). Among the 78 cooked samples that were speciated, iAs concentrations were higher in conventional samples (GM = 1.8 µg/kg; 95% CI: 1.4, 2.3) than in antibiotic-free (GM = 0.7 µg/kg; 95% CI: 0.5, 1.0) or organic (GM = 0.6 µg/kg; 95% CI: 0.5, 0.8) samples. Roxarsone was detected in 20 of 40 conventional samples, 1 of 13 antibiotic-free samples, and none of the 25 organic samples. iAs concentrations in roxarsone-positive samples (GM = 2.3 µg/kg; 95% CI: 1.7, 3.1) were significantly higher than those in roxarsone-negative samples (GM = 0.8 µg/kg; 95% CI: 0.7, 1.0). Cooking increased iAs and decreased roxarsone concentrations. We estimated that consumers of conventional chicken would ingest an additional 0.11 µg/day iAs (in an 82-g serving) compared with consumers of organic chicken. Assuming lifetime exposure and a proposed cancer slope factor of 25.7 per milligram per kilogram of body weight per day, this increase in arsenic exposure could result in 3.7 additional lifetime bladder and lung cancer cases per 100,000 exposed persons. Conclusions: Conventional chicken meat had higher iAs concentrations than did conventional antibiotic-free and organic chicken meat samples. Cessation of arsenical drug use could reduce exposure and the burden of arsenic-related disease in chicken consumers.

### 4. MED-2088 · Arsenic species in poultry feather meal.

Organoarsenical drugs are widely used in the production of broiler chickens in the United States. Feathers from these chickens are processed into a meal product that is used as an animal feed additive and as an organic fertilizer. Research conducted to date suggests that arsenical drugs, specifically roxarsone, used in poultry production result in the accumulation of arsenic in the keratinous material of poultry feathers. The use of feather meal product in the human food system and in other settings may result in human exposures to arsenic. Consequently, the presence and nature of arsenic in twelve samples of feather meal product from six US states and China were examined. Since arsenic toxicity is highly species-dependent, speciation analysis using HPLC/ICPMS was performed to determine the biological relevance of detected arsenic. Arsenic was detected in all samples (44-4100 μg kg(-1)) and speciation analyses revealed that inorganic forms of arsenic dominated, representing 37 - 83% of total arsenic. Roxarsone was not detected in the samples (<20 μg As kg(-1)). Feather meal products represent a previously unrecognized source of arsenic in the food system, and may pose additional risks to humans as a result of its use as an organic fertilizer and when animal waste is managed. Copyright © 2011 Elsevier B.V. All rights reserved.

### 5. MED-1810 · Transmissibility of adenovirus-induced adiposity in a chicken model.

**BACKGROUND:** We previously reported that human adenovirus Ad-36 induces adiposity and paradoxically lower levels of serum cholesterol (CHOL) and triglycerides (TG) in animals.

**OBJECTIVE:** To evaluate the transmissibility of Ad-36 and Ad-36 induced adiposity using a chicken model.

**DESIGN:** Experiment 1--four chickens were housed (two per cage) and one from each cage was inoculated with Ad-36. Duration of presence of Ad-36 DNA in the blood of all chickens was monitored. Experiment 2--two groups of chickens were intranasally inoculated with Ad-36 (infected donors, I-D) or media (control donors, C-D). Blood drawn 36 h later from I-D and C-D groups was inoculated into wing veins of recipient chickens (infected receivers, I-R, and control receivers, C-R, respectively). On sacrifice, 5 weeks post-inoculation, blood was drawn, body weight noted and visceral fat was separated and weighed.

**RESULTS:** Experiment 1--Ad-36 DNA appeared in the blood of the inoculated chickens and that of uninoculated chickens (cage mates) within 12 h of inoculation and the viral DNA persisted up to 25 days in the blood. Experiment 2--compared with C-D, visceral and total body fat were significantly greater and CHOL significantly lower for the I-D and I-R. TG were significantly lower for the I-D. Ad-36 was isolated from 12 out of 16 blood samples of the I-D that were used for inoculating I-R chickens. Ad-36 DNA was present in the blood and the adipose tissue of the I-D and I-R but not in the skeletal muscles of animals selected randomly for testing.

**CONCLUSION:** As seen in experiment 1, Ad-36 infection can be transmitted horizontally from an infected chicken to another chicken sharing the cage. Additionally, experiment 2 demonstrated blood-borne transmission of Ad-36-induced adiposity in chickens. Transmissibility of Ad-36-induced adiposity in chicken model raises serious concerns about such a possibility in humans that needs further investigation.

---

<a id="r14"></a>

## R14 · PLAIN-270 · Is Caffeinated Tea Really Dehydrating?

Mesmos documentos de [R12](#r12): MED-4331, MED-5245, MED-878, MED-1645, MED-4439.

---

<a id="r15"></a>

## R15 · PLAIN-2450 · Are Organic Foods Safer?

Contexto: MED-1140, MED-1178, MED-1144, MED-1179, MED-1173 · cerca de 1346 palavras · também usado em: [R20](#r20)

### 1. MED-1140 · Organic food: buying more safety or just peace of mind? A critical review of the literature.

Consumer concern over the quality and safety of conventional food has intensified in recent years, and primarily drives the increasing demand for organically grown food, which is perceived as healthier and safer. Relevant scientific evidence, however, is scarce, while anecdotal reports abound. Although there is an urgent need for information related to health benefits and/or hazards of food products of both origins, generalized conclusions remain tentative in the absence of adequate comparative data. Organic fruits and vegetables can be expected to contain fewer agrochemical residues than conventionally grown alternatives; yet, the significance of this difference is questionable, inasmuch as actual levels of contamination in both types of food are generally well below acceptable limits. Also, some leafy, root, and tuber organic vegetables appear to have lower nitrate content compared with conventional ones, but whether or not dietary nitrate indeed constitutes a threat to human health is a matter of debate. On the other hand, no differences can be identified for environmental contaminants (e.g. cadmium and other heavy metals), which are likely to be present in food from both origins. With respect to other food hazards, such as endogenous plant toxins, biological pesticides and pathogenic microorganisms, available evidence is extremely limited preventing generalized statements. Also, results for mycotoxin contamination in cereal crops are variable and inconclusive; hence, no clear picture emerges. It is difficult, therefore, to weigh the risks, but what should be made clear is that 'organic' does not automatically equal 'safe.' Additional studies in this area of research are warranted. At our present state of knowledge, other factors rather than safety aspects seem to speak in favor of organic food.

### 2. MED-1178 · Are organic foods safer or healthier than conventional alternatives?: a systematic review.

**BACKGROUND:** The health benefits of organic foods are unclear.

**PURPOSE:** To review evidence comparing the health effects of organic and conventional foods.

**DATA SOURCES:** MEDLINE (January 1966 to May 2011), EMBASE, CAB Direct, Agricola, TOXNET, Cochrane Library (January 1966 to May 2009), and bibliographies of retrieved articles.

**STUDY SELECTION:** English-language reports of comparisons of organically and conventionally grown food or of populations consuming these foods.

**DATA EXTRACTION:** 2 independent investigators extracted data on methods, health outcomes, and nutrient and contaminant levels.

**DATA SYNTHESIS:** 17 studies in humans and 223 studies of nutrient and contaminant levels in foods met inclusion criteria. Only 3 of the human studies examined clinical outcomes, finding no significant differences between populations by food type for allergic outcomes (eczema, wheeze, atopic sensitization) or symptomatic Campylobacter infection. Two studies reported significantly lower urinary pesticide levels among children consuming organic versus conventional diets, but studies of biomarker and nutrient levels in serum, urine, breast milk, and semen in adults did not identify clinically meaningful differences. All estimates of differences in nutrient and contaminant levels in foods were highly heterogeneous except for the estimate for phosphorus; phosphorus levels were significantly higher than in conventional produce, although this difference is not clinically significant. The risk for contamination with detectable pesticide residues was lower among organic than conventional produce (risk difference, 30% \[CI, -37% to -23%\]), but differences in risk for exceeding maximum allowed limits were small. Escherichia coli contamination risk did not differ between organic and conventional produce. Bacterial contamination of retail chicken and pork was common but unrelated to farming method. However, the risk for isolating bacteria resistant to 3 or more antibiotics was higher in conventional than in organic chicken and pork (risk difference, 33% \[CI, 21% to 45%\]).

**LIMITATION:** Studies were heterogeneous and limited in number, and publication bias may be present.

**CONCLUSION:** The published literature lacks strong evidence that organic foods are significantly more nutritious than conventional foods. Consumption of organic foods may reduce exposure to pesticide residues and antibiotic-resistant bacteria.

**PRIMARY FUNDING SOURCE:** None.

### 3. MED-1144 · Perceived risks of conventional and organic produce: pesticides, pathogens, and natural toxins.

Public risk perceptions and demand for safer food are important factors shaping agricultural production practices in the United States. Despite documented food safety concerns, little attempt has been made to elicit consumers' subjective risk judgments for a range of food safety hazards or to identify factors most predictive of perceived food safety risks. In this study, over 700 conventional and organic fresh produce buyers in the Boston area were surveyed for their perceived food safety risks. Survey results showed that consumers perceived relatively high risks associated with the consumption and production of conventionally grown produce compared with other public health hazards. For example, conventional and organic food buyers estimated the median annual fatality rate due to pesticide residues on conventionally grown food to be about 50 per million and 200 per million, respectively, which is similar in magnitude to the annual mortality risk from motor vehicle accidents in the United States. Over 90% of survey respondents also perceived a reduction in pesticide residue risk associated with substituting organically grown produce for conventionally grown produce, and nearly 50% perceived a risk reduction due to natural toxins and microbial pathogens. Multiple regression analyses indicate that only a few factors are consistently predictive of higher risk perceptions, including feelings of distrust toward regulatory agencies and the safety of the food supply. A variety of factors were found to be significant predictors of specific categories of food hazards, suggesting that consumers may view food safety risks as dissimilar from one another. Based on study findings, it is recommended that future agricultural policies and risk communication efforts utilize a comparative risk approach that targets a range of food safety hazards.

### 4. MED-1179 · Organic foods: health and environmental advantages and disadvantages.

The US market for organic foods has grown from \$3.5 billion in 1996 to \$28.6 billion in 2010, according to the Organic Trade Association. Organic products are now sold in specialty stores and conventional supermarkets. Organic products contain numerous marketing claims and terms, only some of which are standardized and regulated. In terms of health advantages, organic diets have been convincingly demonstrated to expose consumers to fewer pesticides associated with human disease. Organic farming has been demonstrated to have less environmental impact than conventional approaches. However, current evidence does not support any meaningful nutritional benefits or deficits from eating organic compared with conventionally grown foods, and there are no well-powered human studies that directly demonstrate health benefits or disease protection as a result of consuming an organic diet. Studies also have not demonstrated any detrimental or disease-promoting effects from an organic diet. Although organic foods regularly command a significant price premium, well-designed farming studies demonstrate that costs can be competitive and yields comparable to those of conventional farming techniques. Pediatricians should incorporate this evidence when discussing the health and environmental impact of organic foods and organic farming while continuing to encourage all patients and their families to attain optimal nutrition and dietary variety consistent with the US Department of Agriculture's MyPlate recommendations. This clinical report reviews the health and environmental issues related to organic food production and consumption. It defines the term "organic," reviews organic food-labeling standards, describes organic and conventional farming practices, and explores the cost and environmental implications of organic production techniques. It examines the evidence available on nutritional quality and production contaminants in conventionally produced and organic foods. Finally, this report provides guidance for pediatricians to assist them in advising their patients regarding organic and conventionally produced food choices.

### 5. MED-1173 · Choice of organic foods is related to perceived consequences for human health and to environmentally friendly behaviour.

We designed a questionnaire concerned with attitudes and behaviour towards organic foods, environmentally friendly behaviour (EFB), and perceived consequences of organic food choice in terms of human health, the environment and animal welfare. It was mailed in 1998 to a random nation-wide sample of 2000 Swedish citizens, ages 18-65 years, and 1154 (58%) responded. Self-reported purchase of organic foods was most strongly related to perceived benefit for human health. Performance of EFBs such as refraining from car driving was also a good predictor of purchase frequency. The results indicate that egoistic motives are better predictors of the purchase of organic foods than are altruistic motives.

---

<a id="r16"></a>

## R16 · PLAIN-238 · How Chemically Contaminated Are We?

Mesmos documentos de [R11](#r11): MED-2391, MED-4739, MED-2493, MED-4653, MED-2994.

---

<a id="r17"></a>

## R17 · PLAIN-2850 · More Antibiotics In White Meat or Dark Meat?

Mesmos documentos de [R09](#r09): MED-3891, MED-4358, MED-4983, MED-2584, MED-4482.

---

<a id="r18"></a>

## R18 · PLAIN-2750 · Preventing the Common Cold with Probiotics?

Mesmos documentos de [R05](#r05): MED-3683, MED-3695, MED-3680, MED-3690, MED-4762.

---

<a id="r19"></a>

## R19 · PLAIN-68 · What is Actually in Chicken Nuggets?

Mesmos documentos de [R13](#r13): MED-2991, MED-1797, MED-2492, MED-2088, MED-1810.

---

<a id="r20"></a>

## R20 · PLAIN-2450 · Are Organic Foods Safer?

Mesmos documentos de [R15](#r15): MED-1140, MED-1178, MED-1144, MED-1179, MED-1173.
